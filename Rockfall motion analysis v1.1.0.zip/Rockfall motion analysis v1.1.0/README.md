# Rockfall motion analysis v1.1.0

Rockfall motion signal extraction from high-speed video.